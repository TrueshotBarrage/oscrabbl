let rec check_file f =
  failwith "unimplemented"

open State

let main () =
  failwith "unimplemented"

(* Execute the game engine. *)
let () = main ()
